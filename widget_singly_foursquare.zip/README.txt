=== Foursquare ===
Contributors: Simon Murtha-Smith
Tags: foursquare, sidebar
Requires at least: 2.5
Tested up to: 2.7
Stable tag: 4.3


== Description ==

Display a pie chart of or most checked into cities in your sidebar, via your Singly account!

== Installation ==

NOTE: requires php5-curl

Download https://github.com/smurthas/widget_singly_foursquare/blob/master/widget_singly_foursquare.zip?raw=true
Upload it to the Plugins section of your WP admin page and then activate the plugin.
Navigate over to Appearance -> Widgets and drag "Foursquare Singly" to the sidebar on the right.
Enter your Singly API key (find it at https://singly.com/users/me/settings) and hit save!
Head to the home page and check it out!!!


== Screenshots ==

none yet.