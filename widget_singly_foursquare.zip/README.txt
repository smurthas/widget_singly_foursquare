=== Foursquare ===
Contributors: Simon Murtha-Smith
Tags: foursquare, sidebar
Requires at least: 2.5
Tested up to: 2.7
Stable tag: 4.3


== Description ==

Display a pie chart of or most checked into cities in your sidebar, via your Singly account!

== Installation ==

Place the widget_singly_foursquare.php file in your /wp-content/plugins/ directory
and activate through the administration panel, and then go to the widget panel and
drag it to where you would like to have it!


== Screenshots ==

none yet.